using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using ProductsUI.Models;

namespace ProductsUI.Services;

public class ProductApiService : IProductApiService
{
    private readonly HttpClient _http;
    private readonly ILogger<ProductApiService> _logger;

    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public ProductApiService(HttpClient http, ILogger<ProductApiService> logger)
    {
        _http = http;
        _logger = logger;
    }

    public async Task<IEnumerable<Product>> GetAllAsync(string? category = null)
    {
        var url = string.IsNullOrEmpty(category)
            ? "products"
            : $"products?category={category}";

        var response = await _http.GetAsync(url);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<IEnumerable<Product>>(_jsonOptions)
               ?? Enumerable.Empty<Product>();
    }

    public async Task<Product?> GetByIdAsync(int id)
    {
        var response = await _http.GetAsync($"products/{id}");
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<Product>(_jsonOptions);
    }

    public async Task<Product?> CreateAsync(Product product)
    {
        var json    = JsonSerializer.Serialize(product, _jsonOptions);
        var content = new StringContent(json, Encoding.UTF8, "application/json");
        var response = await _http.PostAsync("products", content);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<Product>(_jsonOptions);
    }

    public async Task<Product?> UpdateAsync(int id, Product product)
    {
        var json    = JsonSerializer.Serialize(product, _jsonOptions);
        var content = new StringContent(json, Encoding.UTF8, "application/json");
        var response = await _http.PutAsync($"products/{id}", content);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<Product>(_jsonOptions);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var response = await _http.DeleteAsync($"products/{id}");
        return response.IsSuccessStatusCode;
    }
}
