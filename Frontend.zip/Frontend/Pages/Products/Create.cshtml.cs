using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProductsUI.Models;
using ProductsUI.Services;

namespace ProductsUI.Pages.Products;

public class CreateModel : PageModel
{
    private readonly IProductApiService _api;
    public CreateModel(IProductApiService api) => _api = api;

    [BindProperty]
    public Product Product { get; set; } = new();

    public void OnGet() { }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid) return Page();
        await _api.CreateAsync(Product);
        TempData["Success"] = $"Product '{Product.Name}' created!";
        return RedirectToPage("Index");
    }
}
