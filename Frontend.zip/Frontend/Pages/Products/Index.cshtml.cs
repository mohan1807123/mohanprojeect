using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProductsUI.Models;
using ProductsUI.Services;

namespace ProductsUI.Pages.Products;

public class IndexModel : PageModel
{
    private readonly IProductApiService _api;

    public IndexModel(IProductApiService api) => _api = api;

    public IEnumerable<Product> Products { get; set; } = [];

    [BindProperty(SupportsGet = true)]
    public string? CategoryFilter { get; set; }

    public async Task OnGetAsync()
        => Products = await _api.GetAllAsync(CategoryFilter);

    public async Task<IActionResult> OnPostDeleteAsync(int id)
    {
        await _api.DeleteAsync(id);
        TempData["Success"] = "Product deleted successfully.";
        return RedirectToPage();
    }
}
