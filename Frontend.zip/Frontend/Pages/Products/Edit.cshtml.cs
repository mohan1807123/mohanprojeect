using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProductsUI.Models;
using ProductsUI.Services;

namespace ProductsUI.Pages.Products;

public class EditModel : PageModel
{
    private readonly IProductApiService _api;
    public EditModel(IProductApiService api) => _api = api;

    [BindProperty]
    public Product Product { get; set; } = new();

    public async Task<IActionResult> OnGetAsync(int id)
    {
        var product = await _api.GetByIdAsync(id);
        if (product is null) return NotFound();
        Product = product;
        return Page();
    }

    public async Task<IActionResult> OnPostAsync(int id)
    {
        if (!ModelState.IsValid) return Page();
        await _api.UpdateAsync(id, Product);
        TempData["Success"] = $"Product '{Product.Name}' updated!";
        return RedirectToPage("Index");
    }
}
