using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProductsUI.Models;
using ProductsUI.Services;

namespace ProductsUI.Pages.Products;

public class DetailsModel : PageModel
{
    private readonly IProductApiService _api;
    public DetailsModel(IProductApiService api) => _api = api;

    public Product Product { get; set; } = new();

    public async Task<IActionResult> OnGetAsync(int id)
    {
        var product = await _api.GetByIdAsync(id);
        if (product is null) return NotFound();
        Product = product;
        return Page();
    }
}
