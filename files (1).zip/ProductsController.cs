using Microsoft.AspNetCore.Mvc;
using MyDotNetApp.Models;

namespace MyDotNetApp.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private static readonly List<Product> _products = new()
    {
        new Product { Id = 1, Name = "Laptop",  Price = 999.99m },
        new Product { Id = 2, Name = "Mouse",   Price = 29.99m  },
        new Product { Id = 3, Name = "Keyboard", Price = 49.99m }
    };

    // GET api/products
    [HttpGet]
    public IActionResult GetAll() => Ok(_products);

    // GET api/products/1
    [HttpGet("{id}")]
    public IActionResult GetById(int id)
    {
        var product = _products.FirstOrDefault(p => p.Id == id);
        return product is null ? NotFound() : Ok(product);
    }

    // POST api/products
    [HttpPost]
    public IActionResult Create([FromBody] Product product)
    {
        product.Id = _products.Max(p => p.Id) + 1;
        _products.Add(product);
        return CreatedAtAction(nameof(GetById), new { id = product.Id }, product);
    }
}
