using Microsoft.AspNetCore.Mvc;
using ProductsAPI.Models;
using ProductsAPI.Services;

namespace ProductsAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class ProductsController : ControllerBase
{
    private readonly IProductService _productService;
    private readonly ILogger<ProductsController> _logger;

    public ProductsController(IProductService productService, ILogger<ProductsController> logger)
    {
        _productService = productService;
        _logger = logger;
    }

    // GET api/products
    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] string? category)
    {
        _logger.LogInformation("Getting all products");
        var products = await _productService.GetAllAsync(category);
        return Ok(products);
    }

    // GET api/products/1
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        _logger.LogInformation("Getting product {Id}", id);
        var product = await _productService.GetByIdAsync(id);
        if (product is null)
            return NotFound(new { message = $"Product {id} not found." });
        return Ok(product);
    }

    // POST api/products
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] Product product)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        _logger.LogInformation("Creating product: {Name}", product.Name);
        var created = await _productService.CreateAsync(product);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    // PUT api/products/1
    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, [FromBody] Product product)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        _logger.LogInformation("Updating product {Id}", id);
        var updated = await _productService.UpdateAsync(id, product);
        if (updated is null)
            return NotFound(new { message = $"Product {id} not found." });
        return Ok(updated);
    }

    // DELETE api/products/1
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        _logger.LogInformation("Deleting product {Id}", id);
        var deleted = await _productService.DeleteAsync(id);
        if (!deleted)
            return NotFound(new { message = $"Product {id} not found." });
        return Ok(new { message = $"Product {id} deleted successfully." });
    }
}
