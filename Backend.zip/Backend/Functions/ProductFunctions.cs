using System.Net;
using System.Text.Json;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using ProductsAPI.Models;
using ProductsAPI.Services;

namespace ProductsAPI.Functions;

public class ProductFunctions
{
    private readonly IProductService _productService;
    private readonly ILogger<ProductFunctions> _logger;

    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = true
    };

    public ProductFunctions(IProductService productService, ILogger<ProductFunctions> logger)
    {
        _productService = productService;
        _logger = logger;
    }

    // ── GET /api/products ────────────────────────────────────────────────────
    [Function("GetAllProducts")]
    public async Task<HttpResponseData> GetAll(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = "products")] HttpRequestData req)
    {
        _logger.LogInformation("GetAllProducts triggered");

        string? category = req.Query["category"];
        var products = await _productService.GetAllAsync(category);

        var response = req.CreateResponse(HttpStatusCode.OK);
        await response.WriteAsJsonAsync(products, _jsonOptions);
        return response;
    }

    // ── GET /api/products/{id} ───────────────────────────────────────────────
    [Function("GetProductById")]
    public async Task<HttpResponseData> GetById(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = "products/{id:int}")] HttpRequestData req,
        int id)
    {
        _logger.LogInformation("GetProductById triggered for ID: {Id}", id);

        var product = await _productService.GetByIdAsync(id);
        if (product is null)
        {
            var notFound = req.CreateResponse(HttpStatusCode.NotFound);
            await notFound.WriteAsJsonAsync(new { message = $"Product {id} not found." });
            return notFound;
        }

        var response = req.CreateResponse(HttpStatusCode.OK);
        await response.WriteAsJsonAsync(product, _jsonOptions);
        return response;
    }

    // ── POST /api/products ───────────────────────────────────────────────────
    [Function("CreateProduct")]
    public async Task<HttpResponseData> Create(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = "products")] HttpRequestData req)
    {
        _logger.LogInformation("CreateProduct triggered");

        var body = await req.ReadAsStringAsync();
        var product = JsonSerializer.Deserialize<Product>(body ?? "", _jsonOptions);

        if (product is null || string.IsNullOrEmpty(product.Name))
        {
            var bad = req.CreateResponse(HttpStatusCode.BadRequest);
            await bad.WriteAsJsonAsync(new { message = "Invalid product data. Name is required." });
            return bad;
        }

        var created = await _productService.CreateAsync(product);
        var response = req.CreateResponse(HttpStatusCode.Created);
        await response.WriteAsJsonAsync(created, _jsonOptions);
        return response;
    }

    // ── PUT /api/products/{id} ───────────────────────────────────────────────
    [Function("UpdateProduct")]
    public async Task<HttpResponseData> Update(
        [HttpTrigger(AuthorizationLevel.Function, "put", Route = "products/{id:int}")] HttpRequestData req,
        int id)
    {
        _logger.LogInformation("UpdateProduct triggered for ID: {Id}", id);

        var body = await req.ReadAsStringAsync();
        var product = JsonSerializer.Deserialize<Product>(body ?? "", _jsonOptions);

        if (product is null)
        {
            var bad = req.CreateResponse(HttpStatusCode.BadRequest);
            await bad.WriteAsJsonAsync(new { message = "Invalid product data." });
            return bad;
        }

        var updated = await _productService.UpdateAsync(id, product);
        if (updated is null)
        {
            var notFound = req.CreateResponse(HttpStatusCode.NotFound);
            await notFound.WriteAsJsonAsync(new { message = $"Product {id} not found." });
            return notFound;
        }

        var response = req.CreateResponse(HttpStatusCode.OK);
        await response.WriteAsJsonAsync(updated, _jsonOptions);
        return response;
    }

    // ── DELETE /api/products/{id} ────────────────────────────────────────────
    [Function("DeleteProduct")]
    public async Task<HttpResponseData> Delete(
        [HttpTrigger(AuthorizationLevel.Function, "delete", Route = "products/{id:int}")] HttpRequestData req,
        int id)
    {
        _logger.LogInformation("DeleteProduct triggered for ID: {Id}", id);

        var deleted = await _productService.DeleteAsync(id);
        if (!deleted)
        {
            var notFound = req.CreateResponse(HttpStatusCode.NotFound);
            await notFound.WriteAsJsonAsync(new { message = $"Product {id} not found." });
            return notFound;
        }

        var response = req.CreateResponse(HttpStatusCode.OK);
        await response.WriteAsJsonAsync(new { message = $"Product {id} deleted successfully." });
        return response;
    }
}
