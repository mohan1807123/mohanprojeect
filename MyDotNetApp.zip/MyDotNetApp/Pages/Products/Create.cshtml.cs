using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MyDotNetApp.Models;
using MyDotNetApp.Services;

namespace MyDotNetApp.Pages.Products;

public class CreateModel : PageModel
{
    private readonly IProductService _productService;

    public CreateModel(IProductService productService)
    {
        _productService = productService;
    }

    [BindProperty]
    public Product Product { get; set; } = new();

    public void OnGet() { }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
            return Page();

        await _productService.CreateAsync(Product);
        TempData["Success"] = $"Product '{Product.Name}' created successfully!";
        return RedirectToPage("Index");
    }
}
