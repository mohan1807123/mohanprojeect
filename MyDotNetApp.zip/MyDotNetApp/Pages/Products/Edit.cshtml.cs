using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MyDotNetApp.Models;
using MyDotNetApp.Services;

namespace MyDotNetApp.Pages.Products;

public class EditModel : PageModel
{
    private readonly IProductService _productService;

    public EditModel(IProductService productService)
    {
        _productService = productService;
    }

    [BindProperty]
    public Product Product { get; set; } = new();

    public async Task<IActionResult> OnGetAsync(int id)
    {
        var product = await _productService.GetByIdAsync(id);
        if (product is null) return NotFound();
        Product = product;
        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
            return Page();

        var updated = await _productService.UpdateAsync(Product);
        if (updated is null) return NotFound();

        TempData["Success"] = $"Product '{Product.Name}' updated successfully!";
        return RedirectToPage("Index");
    }
}
