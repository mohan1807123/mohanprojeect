using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MyDotNetApp.Models;
using MyDotNetApp.Services;

namespace MyDotNetApp.Pages.Products;

public class IndexModel : PageModel
{
    private readonly IProductService _productService;

    public IndexModel(IProductService productService)
    {
        _productService = productService;
    }

    public IEnumerable<Product> Products { get; set; } = [];
    public IEnumerable<string> Categories { get; set; } = [];

    [BindProperty(SupportsGet = true)]
    public string? CategoryFilter { get; set; }

    [BindProperty(SupportsGet = true)]
    public bool? ActiveFilter { get; set; }

    public async Task OnGetAsync()
    {
        Categories = await _productService.GetCategoriesAsync();
        Products   = await _productService.GetAllAsync(CategoryFilter, ActiveFilter ?? true);
    }

    public async Task<IActionResult> OnPostDeleteAsync(int id)
    {
        await _productService.DeleteAsync(id);
        TempData["Success"] = "Product deleted successfully.";
        return RedirectToPage();
    }
}
