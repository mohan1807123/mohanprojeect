using MyDotNetApp.Models;

namespace MyDotNetApp.Services;

public interface IProductService
{
    Task<IEnumerable<Product>> GetAllAsync(string? category = null, bool? isActive = null);
    Task<Product?> GetByIdAsync(int id);
    Task<Product> CreateAsync(Product product);
    Task<Product?> UpdateAsync(Product product);
    Task<bool> DeleteAsync(int id);
    Task<IEnumerable<string>> GetCategoriesAsync();
}
