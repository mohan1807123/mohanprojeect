using Microsoft.Azure.Functions.Worker;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ProductsAPI.Data;
using ProductsAPI.Services;

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureServices((context, services) =>
    {
        // ── Azure SQL via EF Core ────────────────────────────────────────────
        services.AddDbContext<AppDbContext>(options =>
            options.UseSqlServer(
                context.Configuration["SqlConnectionString"],
                sql => sql.EnableRetryOnFailure(5, TimeSpan.FromSeconds(30), null)
            )
        );

        // ── Services ─────────────────────────────────────────────────────────
        services.AddScoped<IProductService, ProductService>();

        // ── App Insights ─────────────────────────────────────────────────────
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();
    })
    .Build();

// ── Auto-run DB migrations on startup ───────────────────────────────────────
using (var scope = host.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.Migrate();
}

host.Run();
