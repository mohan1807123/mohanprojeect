using ProductsAPI.Models;

namespace ProductsAPI.Services;

public interface IProductService
{
    Task<IEnumerable<Product>> GetAllAsync(string? category = null);
    Task<Product?> GetByIdAsync(int id);
    Task<Product> CreateAsync(Product product);
    Task<Product?> UpdateAsync(int id, Product product);
    Task<bool> DeleteAsync(int id);
}
